Files in this directory will be served under your http://yourjenkins/userContent/
